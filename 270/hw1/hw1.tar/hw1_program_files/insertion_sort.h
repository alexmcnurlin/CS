// Alex McNurlin
// 9/14/16
// CS270
// insertion_sort.h

#ifndef INSERTION_H
extern int newArr[];
extern int arrSize;
int insertion_sort(int input[], int inputc);
#endif
