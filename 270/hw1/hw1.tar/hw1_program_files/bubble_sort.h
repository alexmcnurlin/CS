// Alex McNurlin
// 9/14/16
// CS270
// bubble_sort.h

#ifndef BUBBLE_H
extern int newArr[];
extern int arrSize;
int bubble_sort(int input[], int inputc);
#endif
